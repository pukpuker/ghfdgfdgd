1. Установить шрифт ДЛЯ ВСЕХ (пкм установить для всех)
2. создать папку в /fatality/database и кинуть helper_data
3. папку lib перенести в /fatality (должно получиться /fatality/lib)
4. Закинуть helper.lua