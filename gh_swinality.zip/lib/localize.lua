local function vtable_bind(class, _type, index)
    local this = ffi.cast("void***", class)
    local ffitype = ffi.typeof(_type)
    return function (...)
        return ffi.cast(ffitype, this[0][index])(this, ...)
    end
end

local ILocalize             = utils.find_interface("localize.dll", "Localize_001")
local FindSafeRaw           = vtable_bind(ILocalize, "wchar_t*(__thiscall*)(void*, const char*)", 12)
local ConvertUnicodeToAnsi 	= vtable_bind(ILocalize, "int(__thiscall*)(void*, wchar_t*, char*, int)", 16)

local char_arr = ffi.typeof("char[?]")
local function FindSafe(token)
	local Buffer = char_arr(1024)
    ConvertUnicodeToAnsi(FindSafeRaw(token), Buffer, 1024)
    return ffi.string(Buffer)
end

local localize_cache = {}
local function localize(str)
	if str == nil then return "" end

	if localize_cache[str] == nil then
		localize_cache[str] = FindSafe(str)
	end

	return localize_cache[str]
end

return localize